"""AEON Vitals API — nimmt Apple-Health-Daten (Health Auto Export) entgegen
und stellt sie für Dashboard & TRON bereit. Bewusst minimal als Fundament."""
from fastapi import FastAPI, Request
from datetime import datetime, timezone
import json, os

DATA = os.environ.get("AEON_DATA", "/data/vitals.jsonl")
app = FastAPI(title="AEON Vitals API", version="0.1.0")


@app.get("/")
def root():
    return {"service": "aeon-vitals", "status": "ok"}


@app.post("/ingest")
async def ingest(request: Request):
    """Webhook-Ziel für Health Auto Export (iPhone) oder einen Apple Shortcut."""
    payload = await request.json()
    os.makedirs(os.path.dirname(DATA), exist_ok=True)
    record = {"ts": datetime.now(timezone.utc).isoformat(), "data": payload}
    with open(DATA, "a") as f:
        f.write(json.dumps(record) + "\n")
    return {"received": True}


@app.get("/vitals")
def vitals():
    """Letzter Stand — Dashboard/TRON lesen hier."""
    if not os.path.exists(DATA):
        return {"count": 0, "latest": None}
    with open(DATA) as f:
        lines = [l for l in f if l.strip()]
    latest = json.loads(lines[-1]) if lines else None
    return {"count": len(lines), "latest": latest}
