# AEON-Flaggschiff · Windows-PC (Ryzen + RX 6800) · Dual-Boot NixOS
# Startvorlage — auf echter Hardware verfeinern.
# hardware-configuration.nix generiert der NixOS-Installer selbst (nixos-generate-config).
{ config, pkgs, ... }:
{
  imports = [
    ./hardware-configuration.nix
    ../../modules/aeon-theme.nix     # AEON-Design (Stylix)
    ../../modules/tailscale.nix      # Fleet-Mesh
  ];

  # ── Dual-Boot: Windows wird automatisch erkannt ──
  boot.loader.systemd-boot.enable = true;
  boot.loader.systemd-boot.configurationLimit = 8;   # kleine ESP schonen
  boot.loader.efi.canTouchEfiVariables = true;

  networking.hostName = "aeon-rig";
  networking.networkmanager.enable = true;

  time.timeZone = "Europe/Berlin";

  # ── AMD Ryzen ──
  hardware.cpu.amd.updateMicrocode = true;

  # ── RX 6800 (amdgpu) + 32-bit für Gaming ──
  hardware.graphics = {
    enable = true;
    enable32Bit = true;
    extraPackages = with pkgs; [ rocmPackages.clr.icd amdvlk ];
  };

  # ── Gaming ──
  programs.steam.enable = true;
  programs.gamemode.enable = true;
  environment.systemPackages = with pkgs; [ mangohud protonup-qt lutris git vim ];

  # ── Lokale LLM auf der RX 6800 (TRONs Gehirn) ──
  services.ollama = {
    enable = true;
    acceleration = "rocm";
    # RX 6800 = gfx1030; falls ROCm zickt, einkommentieren:
    # environmentVariables.HSA_OVERRIDE_GFX_VERSION = "10.3.0";
  };

  # ── Game-Streaming an Mac/iPhone (Moonlight) ──
  services.sunshine = { enable = true; openFirewall = true; };

  # ── Pi kann den PC für Inferenz aufwecken ──
  networking.interfaces.eth0.wakeOnLan.enable = true;

  # ── Desktop (Beispiel: KDE Plasma 6) ──
  services.xserver.enable = true;
  services.displayManager.sddm.enable = true;
  services.desktopManager.plasma6.enable = true;

  users.users.joshua = {
    isNormalUser = true;
    description = "Joshua";
    extraGroups = [ "wheel" "networkmanager" ];
  };

  system.stateVersion = "25.05";
}
