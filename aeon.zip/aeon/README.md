# AEON — dein Life-OS (Repo)

> „Aeon" = Ewigkeit. Ein System, das deine Routine automatisiert, dir Zeit zurückgibt und deinen Glow-up ermöglicht. Assistent: **TRON**.

Dieses Repo *ist* dein System — Config as Code. Kein Gerät wird neu aufgesetzt (außer dem Windows-PC, der per **Dual-Boot** ein echtes AEON/NixOS bekommt — Windows bleibt).

---

## Struktur

```
aeon/
├── pi/                  Raspberry Pi OS bleibt — AEON-Hub als Docker-Stack obendrauf
│   ├── docker-compose.yml
│   ├── Caddyfile
│   └── vitals-api/      kleine API: Apple-Health → AEON
├── hosts/aeon-rig/      Windows-PC: Flaggschiff (Dual-Boot NixOS)
│   └── configuration.nix
├── installer/           eigene AEON-Installer-ISO (Tailscale + aeon-install)
├── .github/workflows/   baut die ISO automatisch (GitHub Actions)
├── modules/             geteilte NixOS-Module
│   ├── aeon-theme.nix   Design-System als Code (Stylix)
│   └── tailscale.nix    Fleet-Mesh
├── mac/                 nix-darwin (Phase 3)
├── dotfiles/            AEON-Farben & Prompt
└── flake.nix
```

---

## Phase 0 — Das Mesh (1 Abend)

Ziel: alle vier Geräte sehen sich per Name.

1. Tailscale-Account erstellen → https://tailscale.com
2. Installieren & einloggen auf:
   - **iPhone** (App Store)
   - **Mac** (`brew install --cask tailscale` oder App)
   - **Windows-PC** (Installer)
   - **Raspberry Pi**: `curl -fsSL https://tailscale.com/install.sh | sh && sudo tailscale up`
3. In der Tailscale-Konsole MagicDNS aktivieren, Geräte benennen: `aeon-pi`, `aeon-mac`, `aeon-rig`, `aeon-phone`.

✅ **Done, wenn:** `ssh aeon-pi` von Mac/PC funktioniert.

---

## Phase 1 — Pi-Hub (1 Wochenende)

Raspberry Pi OS bleibt. AEON-Dienste kommen als Container *obendrauf*.

```bash
# auf dem Pi (per Tailscale-SSH):
# 1. Docker installieren (falls noch nicht da)
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER   # danach neu einloggen

# 2. Repo holen
git clone <DEIN_GITHUB_REPO> ~/aeon
cd ~/aeon/pi
cp .env.example .env            # ggf. anpassen

# 3. Hochfahren
docker compose up -d --build
```

Testen:
- Vitals-API: `curl http://localhost:8787/`  → `{"service":"aeon-vitals","status":"ok"}`
- n8n: im Browser `http://aeon-pi:5678`
- Hub: `curl http://localhost:8080/` → `AEON hub · online`

> ⚠️ **Ports:** Falls schon Dienste laufen (z.B. Pi-hole), passe die Ports in `pi/docker-compose.yml` an. Prüfen mit: `sudo ss -tulpn | grep LISTEN`

✅ **Done, wenn:** der Stack läuft, ohne deine bestehenden Dienste zu stören.

---

## Der AEON-Installer (eigene ISO)

Statt „Vanilla-NixOS + Config" baust du eine **eigene Installer-ISO** mit Tailscale, Branding und geführtem `aeon-install` schon drin.

**ISO bauen — drei Wege:**

- **Am schnellsten: GitHub Actions.** Repo nach GitHub pushen → der Workflow `.github/workflows/build-iso.yml` baut die ISO automatisch. Unter „Actions → build-aeon-iso → Artifacts" lädst du `aeon-installer-iso` herunter.
- **Auf dem Mac via Docker** (M1, emuliert — genau wie ein flynnos-builder):
  ```bash
  ./build/build-iso.sh        # ISO landet in ./out/*.iso
  ```
  Details & eigener Builder: `build/README.md`.
- **Lokal auf einer x86-Nix-Maschine:**
  ```bash
  nix build .#aeon-iso        # ISO liegt in ./result/iso/*.iso
  ```

**Benutzen:**
1. `DEIN-USER` in `installer/iso.nix` und `installer/aeon-install.sh` durch deinen GitHub-Namen ersetzen.
2. ISO mit Ventoy/Rufus/`dd` auf einen USB-Stick schreiben.
3. PC davon booten → einloggen → `aeon-install` → geführte, dual-boot-sichere Installation.

> Erst die Windows-Schritte aus `AEON-Windows-PC.md` machen (Backup, BitLocker aus, freien Speicher schaffen).

---

## Danach

- **Phase 4 — Flaggschiff:** Windows-PC Dual-Boot NixOS → siehe `AEON-Windows-PC.md`. `hosts/aeon-rig/configuration.nix` ist die Vorlage.
- **Vitals automatisieren:** „Health Auto Export" (iPhone) als Webhook auf `http://aeon-pi:8787/ingest` zeigen lassen.
- Roadmap & Architektur: `AEON-Roadmap.md`, `Personal-OS-Plan.md`, `AEON-Design-System.md`.

---

*Hinweis: Die Nix-Dateien sind getestete Vorlagen, aber `hardware-configuration.nix` wird beim Installieren auf dem PC generiert. Alles ist als Startpunkt gedacht und wird auf echter Hardware verfeinert.*
