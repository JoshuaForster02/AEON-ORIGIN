# AEON — Git & OTA per Terminal

Das Repo ist dein OTA-System: **push → Geräte ziehen → fertig.** Hier alle Befehle.

---

## 1. Einmalig: Repo anlegen & pushen

Auf dem Mac, im entpackten `aeon/`-Ordner:

```bash
cd ~/Downloads/aeon          # dorthin, wo du aeon.zip entpackt hast

git init
git add -A
git commit -m "AEON: initial"
```

**Variante A — mit GitHub CLI (am schnellsten):**

```bash
brew install gh              # falls noch nicht da
gh auth login                # einmal anmelden
gh repo create aeon --private --source=. --remote=origin --push
```

**Variante B — manuell:** Auf github.com ein **privates** Repo `aeon` anlegen (ohne README), dann:

```bash
git branch -M main
git remote add origin git@github.com:DEIN-USER/aeon.git
git push -u origin main
```

> Danach in `installer/iso.nix`, `installer/aeon-install.sh` und `.github/workflows`/Skripten `DEIN-USER` durch deinen GitHub-Namen ersetzen, dann committen & pushen.

---

## 2. Der OTA-Alltag (etwas ändern → veröffentlichen)

```bash
# … Dateien ändern …
git add -A
git commit -m "kurz was geändert wurde"
git push
```

Das ist die „Veröffentlichung". Ab hier können alle Geräte die Änderung ziehen.

---

## 3. Wenn ICH (Claude) später etwas ändere

Ich kann nicht direkt in dein privates Repo schreiben. Der Weg:

1. Ich gebe dir die geänderten Dateien (neues `aeon.zip` oder einzelne Files).
2. Du legst sie über deinen lokalen `aeon/`-Ordner (gleiche Pfade überschreiben).
3. Veröffentlichen:
   ```bash
   cd ~/Downloads/aeon
   git add -A
   git diff --cached --stat      # zeigt, was sich ändert (Kontrolle)
   git commit -m "AEON: Update von Claude"
   git push
   ```

> Optional später: Wenn du den **GitHub-Connector** freigibst, kann ich Änderungen direkt als Commit/Pull-Request einstellen — dann entfällt das manuelle Kopieren.

---

## 4. Geräte ziehen die Updates

**Pi-Hub (Docker):**
```bash
ssh aeon-pi
cd ~/aeon && ./pi/update.sh        # = git pull + docker compose up -d --build
```

**Flaggschiff (NixOS):**
```bash
cd ~/aeon && git pull
sudo nixos-rebuild switch --flake .#aeon-rig
```

**Installer-ISO:** GitHub Actions baut bei jedem Push automatisch eine neue ISO (Artifacts), oder lokal `./build/build-iso.sh`.

---

## 5. Auto-OTA (optional, später)

Pi alle 15 Min selbst aktualisieren lassen — `crontab -e`:
```
*/15 * * * * /home/USER/aeon/pi/update.sh >> /var/log/aeon-update.log 2>&1
```
(Erst aktivieren, wenn du dem Stack vertraust — sonst lieber manuell `update.sh`.)

---

## Spickzettel

```bash
git status            # was ist geändert?
git add -A            # alles vormerken
git commit -m "..."   # festschreiben
git push              # veröffentlichen (OTA)
git pull              # auf einem Gerät: Update holen
git log --oneline -5  # letzte Änderungen
git revert HEAD       # letzten Commit sicher rückgängig (Rollback)
```
