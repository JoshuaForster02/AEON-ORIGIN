# AEON Installer-ISO — bootfähiges USB-Image mit allem an Bord.
# Baut auf der offiziellen NixOS-Installer-CD auf und ergänzt:
#  - Tailscale (schon im Installer drin)
#  - Tools für die Dual-Boot-Installation (parted, gptfdisk, git)
#  - AEON-Branding + geführtes Skript `aeon-install`
{ pkgs, lib, ... }:
let
  aeon-install = pkgs.writeShellScriptBin "aeon-install" (builtins.readFile ./aeon-install.sh);
in
{
  # Tailscale bereits im Live-Installer verfügbar
  services.tailscale.enable = true;

  # Netzwerk im Installer komfortabel
  networking.networkmanager.enable = true;
  networking.hostName = "aeon-installer";

  # Alles, was der Installer braucht (inkl. dem geführten Skript `aeon-install`)
  environment.systemPackages = with pkgs; [
    git vim curl
    parted gptfdisk ntfs3g   # Partitionen anfassen / NTFS lesen
    tailscale
    aeon-install
  ];

  # AEON-Begrüßung im Login-Screen der Konsole
  services.getty.greetingLine = lib.mkForce ''

      █  AEON Installer  █

      1) Internet/Tailscale prüfen
      2) In Windows vorher freien Speicher schaffen (Partition verkleinern)
      3) Geführte Installation starten:   aeon-install
  '';

  # Repo-URL fürs Install-Skript (anpassen!)
  environment.variables.AEON_REPO = "https://github.com/DEIN-USER/aeon";

  # ISO etwas schlanker / schneller
  isoImage.squashfsCompression = "zstd -Xcompression-level 6";
}
