#!/usr/bin/env bash
# AEON — geführte Dual-Boot-Installation.
# Sicher by design: zerstört NICHTS automatisch. Du wählst die AEON-Partition,
# das Skript erledigt den Rest (Config generieren + installieren).
set -euo pipefail

AEON_REPO="${AEON_REPO:-https://github.com/DEIN-USER/aeon}"

echo
echo "════════════════════════════════════════════"
echo "   AEON · geführte Installation (Dual-Boot)"
echo "════════════════════════════════════════════"
echo
echo "Voraussetzung: In Windows hast du bereits FREIEN Speicher geschaffen"
echo "(Windows-Partition verkleinert). Wir fassen Windows NICHT an."
echo
lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINT,LABEL
echo

read -rp "Auf welcher Festplatte liegt der freie Speicher? (z.B. nvme0n1): " DISK
DISK="/dev/${DISK}"
echo
echo ">> Öffne cfdisk auf ${DISK}."
echo "   Lege im FREIEN Bereich an:  1x Linux-root (Rest)  +  optional Swap."
echo "   Die bestehende EFI-Partition (Windows) NICHT löschen/formatieren!"
read -rp "   [Enter] zum Öffnen von cfdisk ..."
cfdisk "${DISK}"

echo
lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINT,LABEL "${DISK}"
echo
read -rp "Welche Partition ist AEON-root? (z.B. nvme0n1p5): " ROOT
read -rp "Welche Partition ist die bestehende EFI? (z.B. nvme0n1p1): " ESP
ROOT="/dev/${ROOT}"; ESP="/dev/${ESP}"

echo
echo "ACHTUNG: ${ROOT} wird als ext4 formatiert (AEON-root)."
echo "         ${ESP} wird NUR eingebunden, NICHT formatiert."
read -rp "Fortfahren? (tippe 'JA'): " OK
[ "$OK" = "JA" ] || { echo "Abgebrochen."; exit 1; }

mkfs.ext4 -L aeon-root "${ROOT}"
mount "${ROOT}" /mnt
mkdir -p /mnt/boot
mount "${ESP}" /mnt/boot

echo ">> Generiere hardware-configuration.nix für deine Hardware ..."
nixos-generate-config --root /mnt

echo ">> Hole AEON-Repo ..."
git clone "${AEON_REPO}" /mnt/etc/nixos/aeon || true
cp /mnt/etc/nixos/hardware-configuration.nix /mnt/etc/nixos/aeon/hosts/aeon-rig/hardware-configuration.nix

echo ">> Installiere AEON (Flaggschiff aeon-rig) ..."
nixos-install --flake /mnt/etc/nixos/aeon#aeon-rig

echo
echo "✓ Fertig. Nach dem Neustart zeigt das Boot-Menü AEON und Windows."
echo "  Danach einmal:  sudo tailscale up"
