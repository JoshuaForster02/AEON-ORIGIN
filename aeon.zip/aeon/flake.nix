{
  description = "AEON — ein persönliches Life-OS (Fleet)";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-25.05";
    home-manager = {
      url = "github:nix-community/home-manager/release-25.05";
      inputs.nixpkgs.follows = "nixpkgs";
    };
    stylix.url = "github:danth/stylix/release-25.05";
    # Für den Mac später:
    # nix-darwin.url = "github:LnL7/nix-darwin";
  };

  outputs = { self, nixpkgs, home-manager, stylix, ... }:
    let system = "x86_64-linux";
    in {
      # ── Flaggschiff: Windows-PC (Dual-Boot NixOS) ──
      nixosConfigurations.aeon-rig = nixpkgs.lib.nixosSystem {
        inherit system;
        modules = [
          ./hosts/aeon-rig/configuration.nix
          stylix.nixosModules.stylix
        ];
      };

      # ── AEON-Installer-ISO (Tailscale + Branding + aeon-install drin) ──
      nixosConfigurations.aeon-iso = nixpkgs.lib.nixosSystem {
        inherit system;
        modules = [
          ({ modulesPath, ... }: {
            imports = [ "${modulesPath}/installer/cd-dvd/installation-cd-minimal.nix" ];
          })
          ./installer/iso.nix
        ];
      };

      # Bequemer Build:  nix build .#aeon-iso
      packages.${system}.aeon-iso =
        self.nixosConfigurations.aeon-iso.config.system.build.isoImage;

      # ── Mac (nix-darwin) folgt in Phase 3 ──
      # darwinConfigurations.aeon-mac = ...
    };
}
