# AEON Desktop-Design (plasma-manager).
# Stylix liefert Farben/Schriften/Cursor; hier: Icons, Wallpaper, eigene Leiste, Akzent.
{ ... }:
{
  home.stateVersion = "25.05";

  programs.plasma = {
    enable = true;

    workspace = {
      iconTheme = "Papirus-Dark";
      wallpaper = ../assets/aeon-wallpaper.png;
    };

    # Gold-Akzent in der gesamten Oberfläche
    configFile.kdeglobals.General.AccentColor = "201,164,88";

    # Eigene, schwebende AEON-Leiste unten
    panels = [
      {
        location = "bottom";
        height = 44;
        floating = true;
        widgets = [
          "org.kde.plasma.kickoff"
          "org.kde.plasma.icontasks"
          "org.kde.plasma.marginsseparator"
          "org.kde.plasma.systemtray"
          "org.kde.plasma.digitalclock"
          "org.kde.plasma.showdesktop"
        ];
      }
    ];
  };
}
