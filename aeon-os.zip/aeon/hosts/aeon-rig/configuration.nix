# AEON-Flaggschiff · Windows-PC (Ryzen + RX 6800) · Dual-Boot NixOS
# Fertiger, gebrandeter Desktop. hardware-configuration.nix generiert der Installer.
{ config, pkgs, ... }:
let
  # Ablenkende Domains für den Focus-Modus
  focusBlocklist = ''
    0.0.0.0 youtube.com www.youtube.com m.youtube.com
    0.0.0.0 instagram.com www.instagram.com
    0.0.0.0 tiktok.com www.tiktok.com
    0.0.0.0 reddit.com www.reddit.com
    0.0.0.0 x.com twitter.com www.twitter.com
    0.0.0.0 netflix.com www.netflix.com
    0.0.0.0 twitch.tv www.twitch.tv
  '';
in
{
  imports = [
    ./hardware-configuration.nix
    ../../modules/aeon-theme.nix     # AEON-Design (Stylix + Wallpaper)
    ../../modules/tailscale.nix      # Fleet-Mesh
    ../../modules/aeon-modes.nix     # aeon-focus / aeon-unfocus
    ../../modules/aeon-tron.nix      # `tron "..."` — LLM im Terminal
    ../../modules/aeon-shell.nix     # Fish + Starship + Greeting
    ../../modules/aeon-cli.nix       # `aeon` — das Command-Center
    ../../modules/aeon-virtualisation.nix  # KVM/libvirt — Windows & Distros als VM
    ../../modules/aeon-vfio.nix      # Single-GPU-Passthrough (RX 6800 → Windows-VM)
    ../../modules/aeon-launchers.nix # Klickbare AEON-Aktionen im App-Menü
    ../../modules/aeon-sound.nix     # Eigener Startup-Sound beim Login
    ../../modules/aeon-cockpit.nix   # Web-VM-Fernsteuerung (optional, abschaltbar)
  ];

  # ── Dual-Boot: GRUB mit AEON-Theme, erkennt Windows automatisch ──
  # (Falls GRUB mal zickt: diesen Block durch systemd-boot ersetzen:
  #   boot.loader.systemd-boot.enable = true;
  #   boot.loader.systemd-boot.configurationLimit = 8; )
  boot.loader.grub = {
    enable = true;
    efiSupport = true;
    device = "nodev";
    useOSProber = true;                  # findet Windows
    theme = ../../assets/grub;           # AEON Noir-Gold-Bootmenü
    gfxmodeEfi = "1920x1080";
    configurationLimit = 8;
  };
  boot.loader.efi.canTouchEfiVariables = true;
  boot.kernelParams = [ "quiet" ];
  boot.plymouth.enable = true;        # gebrandeter Boot-Splash (von Stylix gethemed)
  boot.tmp.cleanOnBoot = true;

  networking.hostName = "aeon-rig";
  networking.networkmanager.enable = true;

  # ── Region: Deutsch ──
  time.timeZone = "Europe/Berlin";
  i18n.defaultLocale = "de_DE.UTF-8";
  console.keyMap = "de";
  services.xserver.xkb = { layout = "de"; variant = ""; };

  # ── AMD Ryzen + Firmware ──
  hardware.cpu.amd.updateMicrocode = true;
  hardware.enableRedistributableFirmware = true;
  hardware.bluetooth.enable = true;
  hardware.bluetooth.powerOnBoot = true;

  # ── RX 6800 (amdgpu) + 32-bit für Gaming ──
  # RADV/Mesa liefert Vulkan out-of-the-box — robust fürs Erst-Setup.
  # (amdvlk / ROCm-OpenCL bei Bedarf später per OTA ergänzen.)
  hardware.graphics = {
    enable = true;
    enable32Bit = true;
  };

  # ── Audio (PipeWire) ──
  services.pulseaudio.enable = false;
  security.rtkit.enable = true;
  services.pipewire = {
    enable = true;
    alsa.enable = true;
    alsa.support32Bit = true;
    pulse.enable = true;
  };

  # ── Desktop: KDE Plasma 6 (Wayland) ──
  services.xserver.enable = true;
  services.displayManager.sddm.enable = true;
  services.displayManager.sddm.wayland.enable = true;
  services.desktopManager.plasma6.enable = true;

  # ── Unfree erlauben + Flakes + automatische Pflege ──
  nixpkgs.config.allowUnfree = true;
  nix.settings.experimental-features = [ "nix-command" "flakes" ];
  nix.settings.auto-optimise-store = true;
  nix.gc = { automatic = true; dates = "weekly"; options = "--delete-older-than 14d"; };

  # ── Gaming ──
  programs.steam.enable = true;
  programs.gamemode.enable = true;

  # ── Lokale LLM (TRONs Gehirn) ──
  # Erst-Boot CPU-sicher. GPU-Beschleunigung per OTA aktivieren (eine Zeile):
  #   acceleration = "rocm";  +  ggf. HSA_OVERRIDE_GFX_VERSION = "10.3.0";
  services.ollama.enable = true;

  # ── Game-Streaming an Mac/iPhone (Moonlight) ──
  services.sunshine = {
    enable = true;
    openFirewall = true;
    capSysAdmin = true;
  };

  # ── System-Pflege ──
  services.openssh.enable = true;
  services.fwupd.enable = true;        # Firmware-Updates
  services.fstrim.enable = true;       # SSD-TRIM
  networking.interfaces.eth0.wakeOnLan.enable = true;   # Pi weckt den PC

  # ── Browser + Lern-Apps ──
  programs.firefox.enable = true;

  # ── Schriften (AEON-Designsprache + sauberes Rendering) ──
  fonts.packages = with pkgs; [
    inter
    ibm-plex
    (google-fonts.override { fonts = [ "Newsreader" ]; })
    nerd-fonts.jetbrains-mono
    noto-fonts
    noto-fonts-emoji
    noto-fonts-cjk-sans
  ];

  environment.systemPackages = with pkgs; [
    git vim wget curl htop fastfetch
    kitty                       # Terminal (von Stylix gethemed)
    anki                        # Lernen
    obsidian                    # Notizen
    vlc
    mangohud protonup-qt lutris # Gaming-Komfort
    papirus-icon-theme          # dunkle Icons (von plasma-manager gesetzt)
  ];

  # ── Focus-Modus als Boot-Profil (hartes Blocking) ──
  specialisation.focus.configuration = {
    system.nixos.tags = [ "focus" ];
    networking.extraHosts = focusBlocklist;
  };

  users.users.joshua = {
    isNormalUser = true;
    description = "Joshua";
    extraGroups = [ "wheel" "networkmanager" ];
    initialPassword = "aeon";   # ⚠️ nach erstem Login ändern:  passwd
  };

  system.stateVersion = "25.05";
}
