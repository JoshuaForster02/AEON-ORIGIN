"""AEON Hub API.
- nimmt Apple-Health-Daten (Health Auto Export) entgegen   → POST /ingest
- liefert normalisierte Vitals fürs Dashboard               → GET  /vitals
- baut ein kurzes Tagesbriefing                             → GET  /briefing
- TRON: leitet Prompts an die lokale LLM (Ollama, RX 6800)  → POST /tron
"""
import os, json
from datetime import datetime, timezone
from fastapi import FastAPI, Request
import httpx

DATA = os.environ.get("AEON_DATA", "/data/vitals.jsonl")
OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://aeon-rig:11434")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "qwen2.5:14b")

app = FastAPI(title="AEON Hub API", version="0.2.0")


def _latest_raw():
    if not os.path.exists(DATA):
        return None
    with open(DATA) as f:
        lines = [l for l in f if l.strip()]
    return json.loads(lines[-1]) if lines else None


def _metric(payload, names):
    """Health Auto Export: {'data': {'metrics': [{'name','data':[{...}]}]}}"""
    try:
        metrics = payload["data"]["metrics"]
    except Exception:
        return None
    for m in metrics:
        if m.get("name") in names and m.get("data"):
            d = m["data"][-1]
            for k in ("qty", "Avg", "avg", "value", "total"):
                if k in d:
                    return d[k]
    return None


@app.get("/")
def root():
    return {"service": "aeon-hub", "status": "ok"}


@app.post("/ingest")
async def ingest(request: Request):
    payload = await request.json()
    os.makedirs(os.path.dirname(DATA), exist_ok=True)
    with open(DATA, "a") as f:
        f.write(json.dumps({"ts": datetime.now(timezone.utc).isoformat(),
                            "data": payload}) + "\n")
    return {"received": True}


@app.get("/vitals")
def vitals():
    rec = _latest_raw()
    payload = rec["data"] if rec else {}
    sleep = _metric(payload, {"sleep_analysis"})
    steps = _metric(payload, {"step_count"})
    exercise = _metric(payload, {"apple_exercise_time"})
    return {
        "updated": rec["ts"] if rec else None,
        "streak":   {"value": None, "unit": "Tage", "source": "anki (todo)"},
        "focus":    {"value": None, "unit": "h",    "source": "aeon"},
        "sleep":    {"value": round(sleep, 1) if sleep else None, "unit": "h", "source": "apple health"},
        "training": {"value": int(exercise) if exercise else None, "unit": "min", "source": "apple health"},
        "steps": int(steps) if steps else None,
    }


@app.get("/briefing")
def briefing():
    v = vitals()
    parts = []
    if v["sleep"]["value"]:
        parts.append(f'{v["sleep"]["value"]} h Schlaf')
    if v["steps"]:
        parts.append(f'{v["steps"]} Schritte')
    if v["training"]["value"]:
        parts.append(f'{v["training"]["value"]} min Training')
    line = " · ".join(parts) if parts else \
        "Noch keine Health-Daten — sende sie via Health Auto Export an /api/ingest."
    return {"line": line}


@app.post("/tron")
async def tron(request: Request):
    body = await request.json()
    prompt = (body or {}).get("prompt", "").strip()
    if not prompt:
        return {"reply": "Sag mir, was ich tun soll.", "via": "noop"}
    try:
        async with httpx.AsyncClient(timeout=60) as c:
            r = await c.post(f"{OLLAMA_URL}/api/generate",
                             json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": False})
            r.raise_for_status()
            return {"reply": r.json().get("response", "").strip(), "via": "ollama"}
    except Exception as e:
        return {"reply": f"(TRON offline — der PC mit der RX 6800 ist nicht erreichbar: {type(e).__name__})",
                "via": "fallback"}
