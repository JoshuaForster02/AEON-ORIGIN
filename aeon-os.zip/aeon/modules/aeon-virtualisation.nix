# AEON als Hypervisor-Basis ("GrundOS").
# Macht AEON zur leistungsfähigen Virtualisierungs-Plattform:
#  - Windows als VM (ohne dual-boot)
#  - jede beliebige Distro als VM → maximale Flexibilität, Basis bleibt OTA
#  - GPU-Passthrough (VFIO) ist vorbereitet (IOMMU an) und später scharfschaltbar
{ pkgs, ... }:
{
  # Leistungsstarker Desktop/Gaming-Kernel (Zen). Alternativen: linuxPackages_latest,
  # linuxPackages_xanmod_latest. Bewusst gewählt für Responsiveness + KVM.
  boot.kernelPackages = pkgs.linuxPackages_zen;

  # IOMMU für (späteres) GPU-Passthrough vorbereiten (Ryzen).
  boot.kernelParams = [ "amd_iommu=on" "iommu=pt" ];

  # KVM/QEMU + libvirt + grafische Verwaltung
  virtualisation.libvirtd = {
    enable = true;
    qemu = {
      package = pkgs.qemu_kvm;
      runAsRoot = false;
      ovmf.enable = true;     # UEFI-Firmware für die Windows-VM
      swtpm.enable = true;    # TPM 2.0 — von Windows 11 verlangt
    };
  };
  programs.virt-manager.enable = true;

  # Joshua darf VMs verwalten (wird mit wheel/networkmanager gemerged)
  users.users.joshua.extraGroups = [ "libvirtd" "kvm" ];

  environment.systemPackages = with pkgs; [
    virtiofsd       # schneller Datei-Share Host↔VM
    looking-glass-client   # für (späteres) Single-GPU-Passthrough-Streaming
  ];
}
