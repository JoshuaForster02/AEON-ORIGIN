# AEON-Modi als Befehle: `aeon-focus` / `aeon-unfocus`.
# Hartes Distraction-Blocking läuft über die Boot-Specialisation „focus"
# (siehe configuration.nix). Diese Skripte starten/Beenden die Lern-Umgebung.
{ pkgs, ... }:
let
  focus = pkgs.writeShellScriptBin "aeon-focus" ''
    echo "🎯 AEON Focus — Lern-Umgebung wird gestartet ..."
    ${pkgs.anki}/bin/anki >/dev/null 2>&1 &
    ${pkgs.firefox}/bin/firefox --new-window \
      https://app.amboss.com https://www.perplexity.ai https://notion.so \
      >/dev/null 2>&1 &
    echo "Tipp: Für hartes Blocking ins Boot-Profil 'AEON · Focus' starten"
    echo "(blockt YouTube, Insta, TikTok, Reddit, X per /etc/hosts)."
  '';
  unfocus = pkgs.writeShellScriptBin "aeon-unfocus" ''
    echo "Focus beendet. Wenn du im 'AEON · Focus'-Profil bist:"
    echo "ins normale 'AEON'-Profil neu starten, um die Sperren aufzuheben."
  '';
in
{
  environment.systemPackages = [ focus unfocus ];
}
